# Work HQ

A planner for a photographer: jobs, the week, money, studio equipment and meetings.
It is a static site. There is no build step and no server.

## Deploy on Vercel

**With GitHub (easiest to update later)**

1. Create a new repository on github.com and upload every file in this folder.
2. On vercel.com, choose Add New, then Project, and import that repository.
3. Framework Preset: Other. Leave Build Command and Output Directory empty.
4. Press Deploy. Vercel gives you a link such as `work-hq.vercel.app`.

**With the Vercel CLI**

```
npm i -g vercel
cd work-hq-vercel
vercel --prod
```

## Put it on an iPhone home screen

Open the link in Safari, tap Share, then Add to Home Screen. It opens full screen like an app.

## Where the data lives

Everything is saved in the browser on the device being used. Nothing is sent to a server.
Phone and laptop do not sync. To move data, use Guide, Settings, Copy backup on one device
and Restore on the other. Clearing Safari's website data erases it, so copy a backup now and then.

## Files

- `index.html` the whole app
- `manifest.webmanifest`, `icon*.png`, `icon.svg`, `apple-touch-icon.png` home screen name and icon
- `sw.js` lets the app open without a connection
- `vercel.json` Vercel settings
